package myExceptions;

public class UsernameExistsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3646598664131286133L;
	public static final String company_Name_Already_Exist = "Company name already exist";
	public static final String customer_Name_Already_Exist = "Customer name already exist";
	public static final String coupon_Title_Already_Exist = "Coupon title already exist";
	
	public UsernameExistsException(String message) {
		super(message);
	}

}
