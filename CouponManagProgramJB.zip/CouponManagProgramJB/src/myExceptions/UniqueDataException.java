package myExceptions;

public class UniqueDataException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2741472541994079100L;
	public static final String purchased_Coupon = "Purchase is unavailable. Customer already purchased this coupon.";
	
	public UniqueDataException(String message) {
		super(message);
	}

}
