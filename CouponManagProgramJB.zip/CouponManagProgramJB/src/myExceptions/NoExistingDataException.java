package myExceptions;

public class NoExistingDataException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5718138894985319007L;
	public static final String company_Coupons_doesnt_exist = "This company doesn't have any existing coupons";
	public static final String company_Coupons_for_type_doesnt_exist = "This company doesn't have any existing coupons of this type: ";
	public static final String no_Customer_Purchase_exist = "Customer doesn't have any purchases";
	public static final String no_Customer_Purchase_for_type_exist = "Customer doesn't have any purchases for this coupon type: ";
	public static final String no_Customer_Purchase_for_price_exist = "Customer doesn't have any purchases in this price: ";
	
	public NoExistingDataException(String message) {
		super(message);
	}

}
