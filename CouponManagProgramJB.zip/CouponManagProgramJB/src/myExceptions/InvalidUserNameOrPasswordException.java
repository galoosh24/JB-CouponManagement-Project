package myExceptions;

public class InvalidUserNameOrPasswordException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2837093420130852690L;
	public static final String invalid_UserName_Or_Password = "Invalid username or password";

	
	public InvalidUserNameOrPasswordException(String message) {
		super(message);
	}
}
