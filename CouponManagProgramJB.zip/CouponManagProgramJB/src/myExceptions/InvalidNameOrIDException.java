package myExceptions;

public class InvalidNameOrIDException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7849818441218640074L;
	public static final String invalid_Compnay_Name = "Invalid Company Name";
	public static final String invalid_Compnay_ID = "Invalid Company ID";
	public static final String invalid_Customer_Name = "Invalid Customer Name";
	public static final String invalid_Customer_ID = "Invalid Customer ID";
	public static final String invalid_Coupon_Title = "Invalid Coupon Title";
	public static final String invalid_Coupon_ID = "Invalid Coupon ID";
	
	public InvalidNameOrIDException(String message) {
		super(message);
	}

}
