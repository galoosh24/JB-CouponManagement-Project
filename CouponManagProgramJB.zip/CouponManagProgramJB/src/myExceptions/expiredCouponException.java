package myExceptions;

public class expiredCouponException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3425791869152313476L;
	public static final String amount_Equals_0 = "No coupons available";
	public static final String expired_End_Date = "This coupon date has expired";

	public expiredCouponException(String message) {
		super(message);
	}

}
