package generalPackage;

import java.sql.Date;
import java.util.Scanner;

import facadePackage.AdminFacade;
import facadePackage.ClientType;
import facadePackage.CompanyFacade;
import facadePackage.CustomerFacade;
import javaBeans.Company;
import javaBeans.Coupon;
import javaBeans.CouponType;
import javaBeans.Customer;
import myExceptions.InvalidUserNameOrPasswordException;

public class Main {
	
	public static CouponSystem couponSystem = null;

	public static void main(String[] args) {
	
		//get the clientType from client
		System.out.println("please choose your client type: admin = 1, company = 2, customer = 3");
		
		Scanner scan = new Scanner(System.in);
		int type = scan.nextInt();
		
		//get couponSystem instance
		couponSystem = CouponSystem.getInstance();
		
		//sorting witch facade methods to activate.
		switch(type) {
		case 1:
			adminMethods();
			break;
		case 2:
			companyMethods();
			break;
		case 3:
			customerMethods();
			break;
		}
		
		couponSystem.shutdown();
	}
	
	public static void adminMethods() {
		AdminFacade adminFacade = null;
		try
		{
			adminFacade = (AdminFacade) couponSystem.login("admin", "1234", ClientType.ADMIN);
		}
		catch (InvalidUserNameOrPasswordException e)
		{
			e.getMessage();
			System.out.println(e);
		}
		
		Company google = new Company();
		google.setCompName("Google");
		google.setPassword("1111");
		google.setEmail("google@gmail.com");
		
		adminFacade.createCompany(google);
		adminFacade.updateCompany(google);
		adminFacade.getCompany(1);
		adminFacade.removeCompany(google);
		adminFacade.getAllCompanies();
		
		Customer myCust = new Customer();
		myCust.setCustName("David");
		myCust.setPassword("2222");
		
		adminFacade.createCustomer(myCust);
		adminFacade.updateCustomer(myCust);
		adminFacade.getCustomer(1);
		adminFacade.getAllCustomers();
		adminFacade.removeCustomer(myCust);
	}
	
	public static void companyMethods() {
		CompanyFacade companyFacade = null;
		try
		{
			companyFacade = (CompanyFacade) couponSystem.login("Google", "1111", ClientType.COMPANY);
		}
		catch (InvalidUserNameOrPasswordException e)
		{
			e.getMessage();
			System.out.println(e);
		}
		
		Coupon coupon = new Coupon();
		coupon.setTitle("coupon1");
		coupon.setStartDate(Date.valueOf("11.01.17"));
		coupon.setEndDate(Date.valueOf("11.03.17"));
		coupon.setAmount(20);
		coupon.setType(CouponType.CAMPING);
		coupon.setMessage(null);
		coupon.setPrice(100);
		coupon.setImage(null);
		
		companyFacade.createCoupon(coupon);
		companyFacade.updateCoupon(coupon);
		companyFacade.getCoupon(1);
		companyFacade.getAllCoupons();
		companyFacade.getCouponByType(CouponType.CAMPING);
		companyFacade.removeCoupon(coupon);
	}
	
	public static void customerMethods() {
		CustomerFacade customerFacade = null;
		try
		{
			customerFacade = (CustomerFacade) couponSystem.login("Dabid", "2222", ClientType.CUSTOMER);
		}
		catch (InvalidUserNameOrPasswordException e)
		{
			e.getMessage();
			System.out.println(e);
		}
		
		Coupon coupon = new Coupon();
		
		customerFacade.purchaseCoupon(coupon);
		customerFacade.getAllPurchasedCoupons();
		customerFacade.getAllPurchasedCouponsByPrice(100);
		customerFacade.getAllPurchasedCouponsByType(CouponType.CAMPING);
	}
	
}
