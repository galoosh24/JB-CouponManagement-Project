package generalPackage;

import java.sql.SQLException;
import java.util.Calendar;

import DAO.CompanyDBDAO;
import DAO.CouponDBDAO;
import DAO.CustomerDBDAO;

public class DailyCouponExpirationTask implements Runnable{
	
	private CustomerDBDAO customerDBDAO = null;
	private CompanyDBDAO companyDBDAO = null;
	private CouponDBDAO couponDBDAO = null;
	private Object key = new Object();
	private boolean quit;
	
	public DailyCouponExpirationTask() {
		this.customerDBDAO = new CustomerDBDAO();
		this.companyDBDAO = new CompanyDBDAO();
		this.couponDBDAO = new CouponDBDAO();
		this.quit = false;
	}

	@Override
	public void run() {
		
		while (!quit)
		{
			synchronized (key)
			{
				long deltaMs = 0;
				try
				{
					Calendar startTime = Calendar.getInstance();
					customerDBDAO.removeExpiredCustomerCoupon();
					companyDBDAO.removeExpiredCompanyCoupon();
					couponDBDAO.removeExpiredCoupons();
					Calendar endTime = Calendar.getInstance();
					deltaMs = endTime.getTimeInMillis() - startTime.getTimeInMillis(); //the amount of the task time
				}
				catch (InterruptedException e1)
				{
					e1.getMessage();
					System.out.println(e1);
				}
				catch (SQLException e2)
				{
					e2.getMessage();
					System.out.println(e2);
				}
				
				try
				{
					key.wait( (86400 * 1000) - deltaMs); //waits 24 hours minus the amount of the task time
				}
				catch (InterruptedException e)
				{
					e.getMessage();
					System.out.println(e);
				}
			}
		}

	}
	
	public void stopTask() {
		
		synchronized (key)
		{
			quit = true;
			key.notify();
		}
	}

}
