package generalPackage;

import java.sql.SQLException;

import facadePackage.AdminFacade;
import facadePackage.ClientCouponFacade;
import facadePackage.ClientType;
import facadePackage.CompanyFacade;
import facadePackage.CustomerFacade;
import myExceptions.InvalidUserNameOrPasswordException;

public class CouponSystem {
	
	private DailyCouponExpirationTask task = null;
	private static CouponSystem instance = null;
	private AdminFacade adminFacade = null;
	private CompanyFacade companyFacade = null;
	private CustomerFacade customerFacade = null;
	
	
	private CouponSystem() {
		this.adminFacade = new AdminFacade();
		this.companyFacade = new CompanyFacade();
		this.customerFacade = new CustomerFacade();
		this.task = new DailyCouponExpirationTask();
		task.run();
	}
	
	public static synchronized CouponSystem getInstance() {
		
		if(instance == null)
			instance = new CouponSystem();
		
		return instance;
		
	}
	
	public ClientCouponFacade login(String username, String password, ClientType clientType) throws InvalidUserNameOrPasswordException {
		ClientCouponFacade result = null;
		
		switch(clientType) {
		
		case ADMIN: adminFacade.login(username, password, clientType);
			result = adminFacade;
			break;
		case COMPANY: companyFacade.login(username, password, clientType);
			result = companyFacade;
			break;
		case CUSTOMER: customerFacade.login(username, password, clientType);
			result = customerFacade;
			break;
		default: System.out.println("Invalid client type");
		}
		
		return result;
	}
	
	public void shutdown() {
		try
		{
			ConnectionPool.closeAllConnections(); //closing connectionPool
		}
		catch (SQLException e1)
		{
			e1.getMessage();
		}
		catch (InterruptedException e2)
		{
			e2.getMessage();
		}
		task.stopTask(); //stop dailyTask
		instance = null;
	}

}   