package generalPackage;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import com.mysql.jdbc.Connection;

public class ConnectionPool {
	
	//database connection fields
	/** indicate the URL connection*/
	private String connectionURL = "jdbc:mysql://127.0.0.1:3306/CouponManagDB?autoReconnect=true&useSSL=false";
	/** indicates the*/
	private String userName = "root";
	private String password = "VH1Fan24";
	
	private Connection connection = null;
	private static ConnectionPool instance = null;
	private static final int numberOfConnections = 5;
	private static Set<Connection> connectionSet = null;
	private static Set<Connection> givenConnectionSet = null;
	private static Object key = new Object();
	
	/**
	 * Constructs a new set containing connections to the SQL database & a second set that'll contain the given connections.
	 * <p>Every connection is set to <tt>TRANSACTION_SERIALIZABLE</tt>, to be specific, blocking access by others to the data that is being accessed by the transaction (statement).
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	private ConnectionPool() throws ClassNotFoundException, SQLException {
		connectionSet = new HashSet<Connection>();
		givenConnectionSet = new HashSet<Connection>();
		Class.forName("com.mysql.jdbc.Driver");
		
		for ( int i = 0; i < numberOfConnections; i++ )
		{
			connection = (Connection) DriverManager.getConnection(connectionURL, userName, password);
			connection.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
			connectionSet.add(connection);
		}
	}
	
	/**
	 * Creates an instance of the class.
	 * @return instance
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public static synchronized ConnectionPool getInstance() throws ClassNotFoundException, SQLException {
		if ( instance == null )
			instance = new ConnectionPool();
		
		return instance;
	}
	
	/**
	 * Returns a connection from the set. This function also transfer the specific connection from the connection pool to the given connection set.
	 * <p>If there a no connections in the set, the thread goes into wait.
	 * @return Connection
	 * @throws InterruptedException
	 */
	public Connection getConnection() throws InterruptedException {
		Iterator<Connection> myIterator = connectionSet.iterator();
		Connection c = null;
		
		synchronized ( key )
		{
			while ( !myIterator.hasNext() )
			{
				key.wait();
			}
			c = myIterator.next();
			connectionSet.remove(c);
			givenConnectionSet.add(c);
		}
		return c;
	}
	
	/**
	 * Return a connection to the connection pool from the given connection set. If there's a thread in wait, notify the thread that there's a free connection.
	 * @param connection
	 */
	public void returnConnection(Connection connection) {
		
		synchronized ( key )
		{
			givenConnectionSet.remove(connection);
			connectionSet.add(connection);
			key.notify();
		}
	}
	
	/**
	 * Closes all connections to the SQL database and dispose the instance.
	 * @throws SQLException
	 * @throws InterruptedException 
	 */
	public static void closeAllConnections() throws SQLException, InterruptedException {
		
		synchronized ( key )
		{
			if ( connectionSet.size() == numberOfConnections )
			{
				Iterator<Connection> myIterator = connectionSet.iterator();
				Connection c = null;
				while ( myIterator.hasNext() )
				{
					c = myIterator.next();
					c.close();
				}
				instance = null;
			}
			else
			{
				Thread.sleep(30*1000);
				Connection c = null;
				Iterator<Connection> givenConIterator = givenConnectionSet.iterator();
				while ( givenConIterator.hasNext() )
				{
					c = givenConIterator.next();
					givenConnectionSet.remove(c);
					connectionSet.add(c);
				}
				
				Iterator<Connection> conSetIterator = connectionSet.iterator();
				while ( conSetIterator.hasNext() )
				{
					c = conSetIterator.next();
					c.close();
				}
				instance = null;
			}
		}
	}
}
