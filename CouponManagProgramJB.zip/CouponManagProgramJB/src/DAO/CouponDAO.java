package DAO;

import java.sql.SQLException;
import java.util.Collection;

import javaBeans.Coupon;
import javaBeans.CouponType;

public interface CouponDAO {
	
	public void creatCoupon(Coupon coupon) throws InterruptedException, SQLException;
	
	public void removeCoupon(Coupon coupon) throws InterruptedException, SQLException;
	
	public void updateCoupon(Coupon coupon) throws InterruptedException, SQLException;
	
	public Coupon getCoupon(long id) throws InterruptedException, SQLException;
	
	public Collection<Coupon> getAllCoupon() throws InterruptedException, SQLException;
	
	public Collection<Coupon> getCouponByType(CouponType type) throws InterruptedException, SQLException;

}
