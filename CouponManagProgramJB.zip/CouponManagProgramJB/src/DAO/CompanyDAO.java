package DAO;

import java.sql.SQLException;
import java.util.Collection;
import javaBeans.Company;
import javaBeans.Coupon;
/**
 * General actions for the Company table. The user of this interface has control over the Company's table data.
 */
public interface CompanyDAO {
	
	/**
	 * Add a new company to the Company table.
	 * <p>
	 * The Company instance should contain: company's Name, Password & Email. The SQL database auto-increment the company's ID.
	 * @param company Company instance that contains all company's details except for company's id.
	 * @throws InterruptedException
	 * @throws SQLException
	 */
	public void createCompany(Company company) throws InterruptedException, SQLException;
	
	/**
	 * Delete a company from the Company table.
	 * @param company Company instance. Can contain only the company name.
	 * @throws InterruptedException
	 * @throws SQLException
	 */
	public void removeCompany(Company company) throws InterruptedException, SQLException;
	
	/**
	 * Update company details except for company's name.
	 * <p>
	 * When using this method, the user can change the company's Password and/or Email. Company's name and ID cannot be changed!
	 * @param company
	 * @throws InterruptedException
	 * @throws SQLException
	 */
	public void updateCompany(Company company) throws InterruptedException, SQLException;
	
	/**
	 * Returns a Company instance that contains all company details.
	 * <p>
	 * The returned instance contains the following information: company's ID, Name, Password & Email.
	 * @param id the company's ID that should be displayed.
	 * @return an instance of type Company that contains all company details.
	 * @throws InterruptedException
	 * @throws SQLException
	 */
	public Company getCompany(long id) throws InterruptedException, SQLException;
	
	/**
	 * Returns an ArrayList containing all the companies in Company's table.
	 * <p>
	 * <tt>Company</tt> the type of elements in this list.
	 * @return an ArrayList containing all the companies in Company's table.
	 * @throws InterruptedException
	 * @throws SQLException
	 */
	public Collection<Company> getAllCompanies() throws InterruptedException, SQLException;
	
	/**
	 * Returns an ArrayList containing all company's coupons.
	 * <p>
	 * <tt>Coupons</tt> the type of elements in this list.
	 * @return an ArrayList containing all company's coupons.
	 * @throws InterruptedException
	 * @throws SQLException
	 */
	public Collection<Coupon> getCoupons() throws InterruptedException, SQLException;
	
	/**
	 * Returns <tt>true</tt> if the Company table contains the specified elements.
	 * @param compName company's Name
	 * @param password company's Password
	 * @return <tt>true</tt> if the Company table contains the specified elements.
	 * @throws InterruptedException
	 * @throws SQLException
	 */
	public boolean login(String compName, String password) throws InterruptedException, SQLException;
	
}
