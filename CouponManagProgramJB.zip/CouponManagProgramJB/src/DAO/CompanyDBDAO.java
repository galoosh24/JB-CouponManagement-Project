package DAO;

import SQLQueriesAndColumnNames.SQLCompanyColumnNames;
import SQLQueriesAndColumnNames.SQLCompanyQueries;
import SQLQueriesAndColumnNames.SQLCompany_CouponColumnNames;
import SQLQueriesAndColumnNames.SQLCompany_CouponQueries;
import SQLQueriesAndColumnNames.SQLCouponColumnNames;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import javaBeans.Company;
import javaBeans.Coupon;
import javaBeans.CouponType;

public class CompanyDBDAO extends ManageInfoInDBDAO<Company> implements CompanyDAO {
	
	private Company company = null; //for company ID
	private CouponType type = null;

	public CompanyDBDAO() {
		
	}
	
	public void setCouponType(CouponType type) {
		this.type = type;
	}
	
	/**
	 * Creates a new company and adds it to the Company table.
	 * 
	 * @param company Company instance that contains all company's details except for company's id.
	 * @throws InterruptedException
	 * @throws SQLException
	 */
	@Override
	public void createCompany(Company company) throws InterruptedException, SQLException {
		PreparedStatement INSERT_COMPANY = null;
		
		INSERT_COMPANY = super.getConnection_PreparedStatement(SQLCompanyQueries.INSERT_COMPANY_QUERY);
		INSERT_COMPANY.setString(1, company.getCompName());
		INSERT_COMPANY.setString(2, company.getPassword());
		INSERT_COMPANY.setString(3, company.getEmail());
		
		super.executeUpdate_ReturnConnection(INSERT_COMPANY);
	}

	@Override
	public void removeCompany(Company company) throws InterruptedException, SQLException {
		PreparedStatement REMOVE_COMPANY = null;
		
		REMOVE_COMPANY = super.getConnection_PreparedStatement(SQLCompanyQueries.DELETE_COMPANY_QUERY);
		REMOVE_COMPANY.setString(1, company.getCompName());
		
		super.executeUpdate_ReturnConnection(REMOVE_COMPANY);
	}

	@Override
	public void updateCompany(Company company) throws InterruptedException, SQLException {
		PreparedStatement UPDATE_COMPANY = null;
		
		UPDATE_COMPANY = super.getConnection_PreparedStatement(SQLCompanyQueries.UPDATE_COMPANY_QUERY);
		UPDATE_COMPANY.setString(1, company.getPassword());
		UPDATE_COMPANY.setString(2, company.getEmail());
		UPDATE_COMPANY.setString(3, company.getCompName());
		
		super.executeUpdate_ReturnConnection(UPDATE_COMPANY);
	}

	@Override
	public Company getCompany(long id) throws InterruptedException, SQLException {
		Company company = new Company();
		PreparedStatement SELECT_COMPANY = null;
		
		SELECT_COMPANY = super.getConnection_PreparedStatement(SQLCompanyQueries.SELECT_COMPANY_QUERY);
		SELECT_COMPANY.setLong(1, id);
		
		super.executeQuery_ReturnConnection(SELECT_COMPANY, company);
		return company;
	}

	@Override
	public Collection<Company> getAllCompanies() throws InterruptedException, SQLException {
		ArrayList<Company> companyList = new ArrayList<>();
		PreparedStatement SELECT_ALL_COMPANIES = null;
		
		SELECT_ALL_COMPANIES = super.getConnection_PreparedStatement(SQLCompanyQueries.SELECT_ALL_COMPANEIS_QUERY);
		
		super.executeQueryWithArrayList_ReturnConnection(SELECT_ALL_COMPANIES, companyList);
		
		return companyList;
	}

	@Override
	public Collection<Coupon> getCoupons() throws InterruptedException, SQLException {
		ArrayList<Coupon> companyCoupons = new ArrayList<>();
		PreparedStatement SELECT_ALL_COMPANY_COUPONS = null;
		PreparedStatement SELECT_ALL_COMPANY_COUPONS_BY_TYPE = null;
		ResultSet rs = null;
		
		if( type == null) //return all coupons
		{
			SELECT_ALL_COMPANY_COUPONS = super.getConnection_PreparedStatement(SQLCompany_CouponQueries.SELECT_ALL_COMPANY_COUPONS_JOIN_QUERY);
			SELECT_ALL_COMPANY_COUPONS.setLong(1, company.getId());
			
			rs = SELECT_ALL_COMPANY_COUPONS.executeQuery();
		}
		else //return all coupons with specific type
		{
			SELECT_ALL_COMPANY_COUPONS_BY_TYPE = getConnection_PreparedStatement(SQLCompany_CouponQueries.SELECT_ALL_COMPANY_COUPONS_BY_TYPE_JOIN_QUERY);
			SELECT_ALL_COMPANY_COUPONS_BY_TYPE.setLong(1, company.getId());
			SELECT_ALL_COMPANY_COUPONS_BY_TYPE.setString(2, type.toString());
			
			rs = SELECT_ALL_COMPANY_COUPONS_BY_TYPE.executeQuery();
		}
		
		while ( rs.next() )
		{
			Coupon coupon = new Coupon();
			coupon.setId(rs.getLong(SQLCouponColumnNames.ID));
			coupon.setTitle(rs.getString(SQLCouponColumnNames.TITLE));
			coupon.setStartDate(rs.getDate(SQLCouponColumnNames.START_DATE));
			coupon.setEndDate(rs.getDate(SQLCouponColumnNames.END_DATE));
			coupon.setAmount(rs.getInt(SQLCouponColumnNames.AMOUNT));
			coupon.setType(CouponType.valueOf(rs.getString(SQLCouponColumnNames.TYPE)));
			coupon.setMessage(rs.getString(SQLCouponColumnNames.MESSAGE));
			coupon.setPrice(rs.getDouble(SQLCouponColumnNames.PRICE));
			coupon.setImage(rs.getString(SQLCouponColumnNames.IMAGE));
			companyCoupons.add(coupon);
		}
		
		super.returnConnection();

		return companyCoupons;
	}

	@Override
	public boolean login(String compName, String password) throws InterruptedException, SQLException {
		PreparedStatement COMPANY_LOGIN = null;
		ResultSet rs = null;
		String companyName = null;
		String passWord = null;
		long id = 0;
		
		COMPANY_LOGIN = super.getConnection_PreparedStatement(SQLCompanyQueries.SELECT_COMPANY_LOGIN_QUERY);
		COMPANY_LOGIN.setString(1, compName);
		COMPANY_LOGIN.setString(2, password);
		
		rs = COMPANY_LOGIN.executeQuery();
		
		while( rs.next() )
		{
			companyName = rs.getString(SQLCompanyColumnNames.COMP_NAME);
			passWord = rs.getString(SQLCompanyColumnNames.PASSWORD);
		}
		
		super.returnConnection();
		
		if( companyName != null && passWord != null )
		{
			company = new Company();
			id = storeCompanyID(companyName);
			company.setId(id);
			
			System.out.println("Loggin Succesfully");
			return true;
		}
		else
		{
			System.out.println("Incorrect UserName/Password");
			return false;
		}
	}
	
	@Override
	public void executeUpdate(PreparedStatement preparedStatement) throws SQLException {
		preparedStatement.executeUpdate();
	}

	@Override
	public void executeQuery(PreparedStatement preparedStatement, Company company) throws SQLException {
		ResultSet rs = null;
		rs = preparedStatement.executeQuery();
		
		while( rs.next() )
		{
			company.setId(rs.getLong(SQLCompanyColumnNames.ID));
			company.setCompName(rs.getString(SQLCompanyColumnNames.COMP_NAME));
			company.setPassword(rs.getString(SQLCompanyColumnNames.PASSWORD));
			company.setEmail(rs.getString(SQLCompanyColumnNames.EMAIL));
		}
	}

	@Override
	public void executeQueryWithArrayLisy(PreparedStatement preparedStatement, ArrayList<Company> companylist) throws SQLException {
		ResultSet rs = null;
		rs = preparedStatement.executeQuery();
		
		while( rs.next() )
		{
			Company company = new Company();
			company.setId(rs.getLong(SQLCompanyColumnNames.ID));
			company.setCompName(rs.getString(SQLCompanyColumnNames.COMP_NAME));
			company.setPassword(rs.getString(SQLCompanyColumnNames.PASSWORD));
			company.setEmail(rs.getString(SQLCompanyColumnNames.EMAIL));
			companylist.add(company);
		}
	}
	
	public boolean verifyIfComp_NameExist(Company company) throws InterruptedException, SQLException {
		PreparedStatement SELECT_COMP_NAME = null;
		ResultSet rs = null;
		String compName = null;
		
		SELECT_COMP_NAME = super.getConnection_PreparedStatement(SQLCompanyQueries.SELECT_COMP_NAME_QUERY);
		SELECT_COMP_NAME.setString(1, company.getCompName());
		
		rs = SELECT_COMP_NAME.executeQuery();
		
		while( rs.next() )
		{
			compName = rs.getString(SQLCompanyColumnNames.COMP_NAME);
		}
		
		super.returnConnection();
		
		if( compName != null )
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public long storeCompanyID(String compName) throws InterruptedException, SQLException {
		PreparedStatement SELECT_COMP_ID = null;
		ResultSet rs = null;
		long id = 0;
		
		SELECT_COMP_ID = super.getConnection_PreparedStatement(SQLCompanyQueries.SELECT_COMP_ID_QUERY);
		SELECT_COMP_ID.setString(1, compName);
		
		rs = SELECT_COMP_ID.executeQuery();
		
		while ( rs.next() )
		{
			id = rs.getLong(SQLCompanyColumnNames.ID);
		}
		
		super.returnConnection();
		
		return id;
	
	}
	
	public void addCompany_Coupon(long comp_ID, long coupon_ID) throws InterruptedException, SQLException {
		PreparedStatement INSERT_COMPANY_COUPON = null;
		
		INSERT_COMPANY_COUPON = super.getConnection_PreparedStatement(SQLCompany_CouponQueries.INSERT_COMPANY_COUPON_QUERY);
		INSERT_COMPANY_COUPON.setLong(1, comp_ID);
		INSERT_COMPANY_COUPON.setLong(2, coupon_ID);
		
		super.executeUpdate_ReturnConnection(INSERT_COMPANY_COUPON);
	}
	
	public void removeCompany_Coupon(long ID, String columnName) throws InterruptedException, SQLException {
		PreparedStatement DELETE_COMPANY_COUPON = null;
		
		if ( columnName == SQLCompany_CouponColumnNames.Company_ID ) //when i want to delete the company_ID from company_coupon
		{
			DELETE_COMPANY_COUPON = super.getConnection_PreparedStatement(SQLCompany_CouponQueries.DELETE_COMPANY_COUPON_BY_COMPANY_ID_QUERY);
		}
		else if ( columnName == SQLCompany_CouponColumnNames.Coupon_ID ) // when i want to delete the coupon_ID from company_coupon
		{
			DELETE_COMPANY_COUPON = super.getConnection_PreparedStatement(SQLCompany_CouponQueries.DELETE_COMPANY_COUPON_BY_COUPON_ID_QUERY);
		}
		else //error, when columnName != to the options above, (not likely to happen)
		{
			System.out.println("error!!! please choose one of the next options for String columnName: Company_ID or Coupon_ID");
		}
		
		DELETE_COMPANY_COUPON.setLong(1, ID);
		
		super.executeUpdate_ReturnConnection(DELETE_COMPANY_COUPON);
	}
	
	public void removeExpiredCompanyCoupon() throws InterruptedException, SQLException {
		PreparedStatement DELETE_EXPIRED_COMPANY_COUPONS = null;
		LocalDate today = LocalDate.now();
		Date currentDate = Date.valueOf(today);
		
		DELETE_EXPIRED_COMPANY_COUPONS = super.getConnection_PreparedStatement(SQLCompany_CouponQueries.DELETE_EXPIRED_COUPONS_FROM_COMPANY_COUPON_QUERY);
		DELETE_EXPIRED_COMPANY_COUPONS.setDate(1, currentDate);
		
		super.executeUpdate_ReturnConnection(DELETE_EXPIRED_COMPANY_COUPONS);
	}
}
