package DAO;

import java.sql.SQLException;
import java.util.Collection;

import javaBeans.Coupon;
import javaBeans.Customer;

public interface CustomerDAO {
	
	public void createCustomer(Customer customer) throws InterruptedException, SQLException;
	
	public void removeCustomer(Customer customer) throws InterruptedException, SQLException;
	
	public void updateCustomer(Customer customer) throws InterruptedException, SQLException;
	
	public Customer getCustomer(long id) throws InterruptedException, SQLException;
	
	public Collection<Customer> getAllCustomers() throws InterruptedException, SQLException;
	
	public Collection<Coupon> getCoupons() throws InterruptedException, SQLException;
	
	public boolean login(String custName, String password) throws InterruptedException, SQLException;
	
}
