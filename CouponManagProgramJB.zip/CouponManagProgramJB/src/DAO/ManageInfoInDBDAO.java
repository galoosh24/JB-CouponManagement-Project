package DAO;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import com.mysql.jdbc.Connection;

import generalPackage.ConnectionPool;
/**
 * Manage information in the SQL database, consists of the Template method Design Pattern.
 * <p>
 * Contains 4 main methods: <tt>1.getConnection</tt>, <tt>2.getPreparedStatement</tt>, <tt>3.execute</tt>, <tt>4.returnConnection</tt>.
 * (The <tt>execute</tt> is an abstract method divided into 3 sections that define 3 different query executions).
 * <p>
 * The template method is divided into 2 sections:
 * <br> <tt>1.getConnection_PreparedStatement</tt> Calls <i>getConnection</i> & <i>getPreparedStatement</i> methods.
 * <br> <tt>2.execute_ReturnConnection</tt> Calls <i>execute</i> & <i>returnConnection</i> methods. (again, this method is divided into 3 sections(methods) depends on the <tt>execute</tt> method).
 * <p> This is the only class that creates the connection to the SQL database using the ConnectionPool. Every class in this project that needs connection to the database extends this class.
 * @author galalony
 *
 * @param <T> the type of elements in this class.
 */
public abstract class ManageInfoInDBDAO<T> {
	
	private ConnectionPool pool = null;
	private Connection connection = null;
	private PreparedStatement preparedStatement = null;
	
	public ManageInfoInDBDAO() {
		try
		{
			this.pool = ConnectionPool.getInstance();
		}
		catch (ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	//Template Algorithm Structure:
	
	/**
	 * Getting a connection from the <tt>ConnectionPool</tt>.
	 * <p>Every connection supports <tt>TRANSACTION_SERIALIZABLE</tt>.
	 * @throws InterruptedException
	 */
	public void getConnection() throws InterruptedException { // method number 1.
		connection = pool.getConnection();
	}
	
	/**
	 * Creates a default <tt>preparedStatement</tt> object.
	 * @param query an SQL statement that may contain one or more '?' IN parameter placeholders.
	 * @throws SQLException
	 */
	public void getPreparedStatement(String query) throws SQLException { //method number 2.
		preparedStatement = connection.prepareStatement(query);
	}
	
	/**
	 * Executes the SQL statement in this <tt>preparedStatement</tt> object, 
	 * which must be an SQL Data Manipulation Language (DML) statement, such as <tt>INSERT</tt>, <tt>UPDATE</tt> or <tt>DELETE</tt>; 
	 * or an SQL statement that returns nothing, such as a DDL statement.
	 * @param preparedStatement a <tt>preparedStatement</tt> object that contains a precompiled SQL statement.
	 * @throws SQLException
	 */
	public abstract void executeUpdate(PreparedStatement preparedStatement) throws SQLException; //method number 3, section 1.
	
	/**
	 * Executes the SQL statement in this <tt>preparedStatement</tt> object and stores the values in the returned <tt>ResultSet</tt> inside the <tt>T</tt> parameter.
	 * @param preparedStatement a <tt>preparedStatement</tt> object that contains a precompiled SQL statement.
	 * @param t the type of element in the inherited class.
	 * @throws SQLException
	 */
	public abstract void executeQuery(PreparedStatement preparedStatement, T t) throws SQLException; //method number 3, section 2.

	/**
	 * Executes the SQL statement in this <tt>preparedStatement</tt> object and stores the values in the returned <tt>ResultSet</tt> inside an ArrayList.
	 * @param preparedStatement a <tt>preparedStatement</tt> object that contains a precompiled SQL statement.
	 * @param tList an ArrayList of type <tt>T</tt> (the type of element in the inherited class);
	 * @throws SQLException
	 */
	public abstract void executeQueryWithArrayLisy(PreparedStatement preparedStatement, ArrayList<T> tList) throws SQLException; //method number 3, section 3.
	
	/**
	 * Returns the connection to the <tt>ConnectionPool</tt>.
	 */
	public void returnConnection() { //method number 4.
		pool.returnConnection(connection);
	}
	
	//Template Method (divided into 2 sections):
	
	/**
	 * Calling the first 2 methods in the <i>Template Algorithm Structure</i>:
	 * <pre> 1. getConnection();
	 * 2. getPreparedStatement();
	 * </pre>
	 * @param query an SQL statement that may contain one or more '?' IN parameter placeholders.
	 * @return a <tt>preparedStatement</tt> object that may contain one or more '?' IN parameter placeholders
	 * @throws InterruptedException
	 * @throws SQLException
	 */
	public PreparedStatement getConnection_PreparedStatement(String query) throws InterruptedException, SQLException { //Template method section 1
		getConnection();
		getPreparedStatement(query);
		
		return preparedStatement;
	}
	
	/**
	 * Calling the last 2 methods in the <i>Template Algorithm Structure</i>:
	 * <pre> 3. executeUpdate();
	 * 4. returnConnection();
	 * </pre>
	 * <b>Note:</b> This method calls method number 3 section 1 of the <tt>execute</tt> methods, were the SQL statement must be a DML statement.
	 * @param preparedStatement a <tt>preparedStatement</tt> object that contains a precompiled SQL statement.
	 * @throws SQLException
	 */
	public void executeUpdate_ReturnConnection(PreparedStatement preparedStatement) throws SQLException { //Template method section 2.1
		executeUpdate(preparedStatement);
		returnConnection();
	}
	
	/**
	 * Calling the last 2 methods in the <i>Template Algorithm Structure</i>:
	 * <pre> 3. executeQuery();
	 * 4. returnConnection();
	 * </pre>
	 * <b>Note:</b> This method calls method number 3 section 2 of the <tt>execute</tt> methods, were the returned values are stored in the <tt>T</tt> parameter.
	 * @param preparedStatement a <tt>preparedStatement</tt> object that contains a precompiled SQL statement.
	 * @param t the type of element in the inherited class.
	 * @throws SQLException
	 */
	public void executeQuery_ReturnConnection( PreparedStatement preparedStatement, T t) throws SQLException { //Template method section 2.2
		executeQuery(preparedStatement, t);
		returnConnection();
	}
	
	/**
	 * Calling the last 2 methods in the <i>Template Algorithm Structure</i>:
	 * <pre> 3. executeQueryWithArrayList_ReturnConnection();
	 * 4. returnConnection();
	 * </pre>
	 * <b>Note:</b> This method calls method number 3 section 3 of the <tt>execute</tt> methods, were the returned values are stored in an ArrayList.
	 * @param preparedStatement a <tt>preparedStatement</tt> object that contains a precompiled SQL statement.
	 * @param tlist an ArrayList of type <tt>T</tt> (the type of element in the inherited class);
	 * @throws SQLException
	 */
	public void executeQueryWithArrayList_ReturnConnection(PreparedStatement preparedStatement, ArrayList<T> tlist) throws SQLException { //Template method section 2.3
		executeQueryWithArrayLisy(preparedStatement, tlist);
		returnConnection();
	}
}
