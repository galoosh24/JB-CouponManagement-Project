package DAO;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;

import SQLQueriesAndColumnNames.SQLCouponColumnNames;
import SQLQueriesAndColumnNames.SQLCouponQueries;
import facadePackage.ClientType;
import javaBeans.Coupon;
import javaBeans.CouponType;
import myExceptions.expiredCouponException;

public class CouponDBDAO extends ManageInfoInDBDAO<Coupon> implements CouponDAO {
	
	private ClientType clientType = null;

	public CouponDBDAO() {
	
	}
	
	public void setClientType(ClientType clientType) {
		this.clientType = clientType;
	}

	@Override
	public void creatCoupon(Coupon coupon) throws InterruptedException, SQLException {
		PreparedStatement INSERT_COUPON = null;
		
		INSERT_COUPON = super.getConnection_PreparedStatement(SQLCouponQueries.INSERT_COUPON_QUERY);
		INSERT_COUPON.setString(1, coupon.getTitle());
		INSERT_COUPON.setDate(2, coupon.getStartDate());
		INSERT_COUPON.setDate(3, coupon.getEndDate());
		INSERT_COUPON.setInt(4, coupon.getAmount());
		INSERT_COUPON.setString(5, coupon.getType().toString());
		INSERT_COUPON.setString(6, coupon.getMessage());
		INSERT_COUPON.setDouble(7, coupon.getPrice());
		INSERT_COUPON.setString(8, coupon.getImage());
		
		super.executeUpdate_ReturnConnection(INSERT_COUPON);
	}

	@Override
	public void removeCoupon(Coupon coupon) throws InterruptedException, SQLException {
		PreparedStatement DELETE_COUPON = null;
		
		DELETE_COUPON = super.getConnection_PreparedStatement(SQLCouponQueries.DELETE_COUPON_QUERY);
		DELETE_COUPON.setString(1, coupon.getTitle());
		
		super.executeUpdate_ReturnConnection(DELETE_COUPON);
	}

	@Override
	public void updateCoupon(Coupon coupon) throws InterruptedException, SQLException {
		PreparedStatement UPDATE_COUPON = null;
		
		if ( clientType == ClientType.COMPANY ) //update coupon's end_date & price
		{
			UPDATE_COUPON = super.getConnection_PreparedStatement(SQLCouponQueries.UPDATE_COUPON_QUERY);
			UPDATE_COUPON.setDate(1, coupon.getEndDate());
			UPDATE_COUPON.setDouble(2, coupon.getPrice());
			UPDATE_COUPON.setString(3, coupon.getTitle());
		}
		else if ( clientType == ClientType.CUSTOMER ) //update coupon's amount
		{
			UPDATE_COUPON = super.getConnection_PreparedStatement(SQLCouponQueries.UPDATE_COUPON_AMOUNT_QUERY);
			UPDATE_COUPON.setString(1, coupon.getTitle());
		}
		else //clientType != company or customer
		{
			System.out.println("error!!!! this condition is invalid");
		}
		
		
		super.executeUpdate_ReturnConnection(UPDATE_COUPON);
	}

	@Override
	public Coupon getCoupon(long id) throws InterruptedException, SQLException {
		Coupon coupon = new Coupon();
		PreparedStatement SELECT_COUPON = null;
		
		SELECT_COUPON = super.getConnection_PreparedStatement(SQLCouponQueries.SELECT_COUPON_QUERY);
		SELECT_COUPON.setLong(1, id);
		
		super.executeQuery_ReturnConnection(SELECT_COUPON, coupon);
		
		return coupon;
	}

	@Override
	public Collection<Coupon> getAllCoupon() throws InterruptedException, SQLException {
		ArrayList<Coupon> couponList = new ArrayList<>();
		PreparedStatement SELECT_ALL_COUPONS= null;
		
		SELECT_ALL_COUPONS = super.getConnection_PreparedStatement(SQLCouponQueries.SELECT_ALL_COUPON_QUERY);
		
		super.executeQueryWithArrayList_ReturnConnection(SELECT_ALL_COUPONS, couponList);
		
		return couponList;
	}

	@Override
	public Collection<Coupon> getCouponByType(CouponType type) throws InterruptedException, SQLException {
		ArrayList<Coupon> couponList = new ArrayList<>();
		PreparedStatement SELECT_ALL_COUPONS_BY_TYPE= null;
		
		SELECT_ALL_COUPONS_BY_TYPE = super.getConnection_PreparedStatement(SQLCouponQueries.SELECT_ALL_COUPON_BY_TYPE_QUERY);
		SELECT_ALL_COUPONS_BY_TYPE.setString(1, type.toString());
		
		super.executeQueryWithArrayList_ReturnConnection(SELECT_ALL_COUPONS_BY_TYPE, couponList);
		
		return couponList;
	}

	
	@Override
	public void executeUpdate(PreparedStatement preparedStatement) throws SQLException {
		preparedStatement.executeUpdate();
	}

	@Override
	public void executeQuery(PreparedStatement preparedStatement, Coupon coupon) throws SQLException {
		ResultSet rs = null;
		rs = preparedStatement.executeQuery();
		
		while( rs.next() )
		{
			coupon.setId(rs.getLong(SQLCouponColumnNames.ID));
			coupon.setTitle(rs.getString(SQLCouponColumnNames.TITLE));
			coupon.setStartDate(rs.getDate(SQLCouponColumnNames.START_DATE));
			coupon.setEndDate(rs.getDate(SQLCouponColumnNames.END_DATE));
			coupon.setAmount(rs.getInt(SQLCouponColumnNames.AMOUNT));
			coupon.setType(CouponType.valueOf(rs.getString(SQLCouponColumnNames.TYPE)));
			coupon.setMessage(rs.getString(SQLCouponColumnNames.MESSAGE));
			coupon.setPrice(rs.getDouble(SQLCouponColumnNames.PRICE));
			coupon.setImage(rs.getString(SQLCouponColumnNames.IMAGE));
		}
	}

	@Override
	public void executeQueryWithArrayLisy(PreparedStatement preparedStatement, ArrayList<Coupon> couponlist) throws SQLException {
		ResultSet rs = null;
		rs = preparedStatement.executeQuery();
		
		while( rs.next() )
		{
			Coupon coupon = new Coupon();
			coupon.setId(rs.getLong(SQLCouponColumnNames.ID));
			coupon.setTitle(rs.getString(SQLCouponColumnNames.TITLE));
			coupon.setStartDate(rs.getDate(SQLCouponColumnNames.START_DATE));
			coupon.setEndDate(rs.getDate(SQLCouponColumnNames.END_DATE));
			coupon.setAmount(rs.getInt(SQLCouponColumnNames.AMOUNT));
			coupon.setType(CouponType.valueOf(rs.getString(SQLCouponColumnNames.TYPE)));
			coupon.setMessage(rs.getString(SQLCouponColumnNames.MESSAGE));
			coupon.setPrice(rs.getDouble(SQLCouponColumnNames.PRICE));
			coupon.setImage(rs.getString(SQLCouponColumnNames.IMAGE));
			couponlist.add(coupon);
		}
	}
	
	public boolean verifyIfCouponTitleExist(Coupon coupon) throws InterruptedException, SQLException {
		PreparedStatement SELECT_COUPON_TITLE = null;
		ResultSet rs = null;
		String title = null;
		
		SELECT_COUPON_TITLE = super.getConnection_PreparedStatement(SQLCouponQueries.SELECT_COUPON_TITLE_QUERY);
		SELECT_COUPON_TITLE.setString(1, coupon.getTitle());
		
		rs = SELECT_COUPON_TITLE.executeQuery();
		
		while( rs.next() )
		{
			title = rs.getString(SQLCouponColumnNames.TITLE);
		}
		
		super.returnConnection();
		
		if( title != null )  //coupon title exist
		{
			return true;
		}
		else // coupon title does not exist
		{
			return false;
		}
	}
	
	public long getCouponID(String coupTitle) throws InterruptedException, SQLException {
		PreparedStatement SELECT_COUPON_ID = null;
		ResultSet rs = null;
		long id = 0;
		
		SELECT_COUPON_ID = super.getConnection_PreparedStatement(SQLCouponQueries.SELECT_COUPON_ID_QUERY);
		SELECT_COUPON_ID.setString(1, coupTitle);
		
		rs = SELECT_COUPON_ID.executeQuery();
		
		while ( rs.next() )
		{
			id = rs.getLong(SQLCouponColumnNames.ID);
		}
		
		super.returnConnection();
		
		return id;
	}
	
	public void removeMultipleCoupons(long companyID) throws InterruptedException, SQLException {
		PreparedStatement DELETE_MULTIPLE_COUPONS = null;
		
		DELETE_MULTIPLE_COUPONS = super.getConnection_PreparedStatement(SQLCouponQueries.DELETE_MULTIPLE_COUPONS_JOIN_QUERY);
		DELETE_MULTIPLE_COUPONS.setLong(1, companyID);
		
		super.executeUpdate_ReturnConnection(DELETE_MULTIPLE_COUPONS);
	}
	
	public boolean verifyAmountAndEnd_Date(Coupon coupon) throws InterruptedException, SQLException, expiredCouponException {
		PreparedStatement SELECT_COUPON_AMOUNT_AND_END_DATE = null;
		ResultSet rs = null;
		LocalDate today = LocalDate.now();
		Date currentDate = Date.valueOf(today);
		
		SELECT_COUPON_AMOUNT_AND_END_DATE = super.getConnection_PreparedStatement(SQLCouponQueries.SELECT_COUPON_AMOUNT_AND_END_DATE);
		SELECT_COUPON_AMOUNT_AND_END_DATE.setString(1, coupon.getTitle());
		
		rs = SELECT_COUPON_AMOUNT_AND_END_DATE.executeQuery();
		
		while ( rs.next() )
		{
			coupon.setAmount(rs.getInt(SQLCouponColumnNames.AMOUNT));
			coupon.setEndDate(rs.getDate(SQLCouponColumnNames.END_DATE));
		}
		
		super.returnConnection();
		
		if ( coupon.getAmount() !=0 ) 
		{
			if ( coupon.getEndDate().after(currentDate) ) //amount > 0 and end_date has not! expired.
			{
				return true;
			}
			else // amount > 0 but end_date has expired!
			{
				throw new expiredCouponException(expiredCouponException.expired_End_Date);
			}
		}
		else //amount = 0;
		{
			throw new expiredCouponException(expiredCouponException.amount_Equals_0);
		}
	}
	
	public void removeExpiredCoupons() throws InterruptedException, SQLException {
		PreparedStatement DELETE_EXPIRED_COUPONS = null;
		LocalDate today = LocalDate.now();
		Date currentDate = Date.valueOf(today);
		
		DELETE_EXPIRED_COUPONS = super.getConnection_PreparedStatement(SQLCouponQueries.DELETE_EXPIRED_COUPONS_QUERY);
		DELETE_EXPIRED_COUPONS.setDate(1, currentDate);
		
		super.executeUpdate_ReturnConnection(DELETE_EXPIRED_COUPONS);
	}
}
	
