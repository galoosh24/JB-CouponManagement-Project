package DAO;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import SQLQueriesAndColumnNames.SQLCouponColumnNames;
import SQLQueriesAndColumnNames.SQLCustomerColumnNames;
import SQLQueriesAndColumnNames.SQLCustomerQueries;
import SQLQueriesAndColumnNames.SQLCustomer_CouponColumnNames;
import SQLQueriesAndColumnNames.SQLCustomer_CouponQueries;
import javaBeans.Coupon;
import javaBeans.CouponType;
import javaBeans.Customer;
import myExceptions.UniqueDataException;

public class CustomerDBDAO extends ManageInfoInDBDAO<Customer> implements CustomerDAO {
	
	private Customer customer = null;
	private CouponType type = null;
	private double price = -1;

	public CustomerDBDAO() {
		
	}
	
	public void setCouponType(CouponType type) {
		this.type = type;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public void createCustomer(Customer customer) throws InterruptedException, SQLException {
		PreparedStatement INSERT_CUSTOMER = null;
		
		INSERT_CUSTOMER = super.getConnection_PreparedStatement(SQLCustomerQueries.INSERT_CUSTOMER_QUERY);
		INSERT_CUSTOMER.setString(1, customer.getCustName());
		INSERT_CUSTOMER.setString(2, customer.getPassword());
		
		super.executeUpdate_ReturnConnection(INSERT_CUSTOMER);
	}

	@Override
	public void removeCustomer(Customer customer) throws InterruptedException, SQLException {
		PreparedStatement DELETE_CUSTOMER = null;
		
		DELETE_CUSTOMER = super.getConnection_PreparedStatement(SQLCustomerQueries.DELETE_CUSTOMER_QUERY);
		DELETE_CUSTOMER.setString(1, customer.getCustName());
		
		super.executeUpdate_ReturnConnection(DELETE_CUSTOMER);
	}

	@Override
	public void updateCustomer(Customer customer) throws InterruptedException, SQLException {
		PreparedStatement UPDATE_CUSTOMER = null;
		
		UPDATE_CUSTOMER = super.getConnection_PreparedStatement(SQLCustomerQueries.UPDATE_CUSTOMER_QUERY);
		UPDATE_CUSTOMER.setString(1, customer.getPassword());
		UPDATE_CUSTOMER.setString(2, customer.getCustName());
		
		super.executeUpdate_ReturnConnection(UPDATE_CUSTOMER);
	}

	@Override
	public Customer getCustomer(long id) throws InterruptedException, SQLException {
		Customer customer = new Customer();
		PreparedStatement SELECT_CUSTOMER = null;
		
		SELECT_CUSTOMER = super.getConnection_PreparedStatement(SQLCustomerQueries.SELECT_CUSTOMER_QUERY);
		SELECT_CUSTOMER.setLong(1, id);
		
		super.executeQuery_ReturnConnection(SELECT_CUSTOMER, customer);
		
		return customer;
	}

	@Override
	public Collection<Customer> getAllCustomers() throws InterruptedException, SQLException {
		ArrayList<Customer> customerList = new ArrayList<>();
		PreparedStatement SELECT_ALL_CUSTOMERS = null;
		
		SELECT_ALL_CUSTOMERS = super.getConnection_PreparedStatement(SQLCustomerQueries.SELECT_ALL_CUSTOMERS_QUERY);
		
		super.executeQueryWithArrayList_ReturnConnection(SELECT_ALL_CUSTOMERS, customerList);
		
		return customerList;
	}

	@Override
	public Collection<Coupon> getCoupons() throws InterruptedException, SQLException {
		ArrayList<Coupon> customerCoupons = new ArrayList<>();
		PreparedStatement SELECT_ALL_CUSTOMER_COUPONS = null;
		PreparedStatement SELECT_ALL_CUSTOMER_COUPONS_BY_TYPE = null;
		PreparedStatement SELECT_ALL_CUSTOMER_COUPONS_BY_PRICE = null;
		ResultSet rs = null;
		
		if ( type == null )
		{
			if ( price == -1 ) // return all coupons
			{
				SELECT_ALL_CUSTOMER_COUPONS = super.getConnection_PreparedStatement(SQLCustomer_CouponQueries.SELECT_ALL_CUSTOMER_COUPONS_JOIN_QUERY);
				SELECT_ALL_CUSTOMER_COUPONS.setLong(1, customer.getId());
				
				rs = SELECT_ALL_CUSTOMER_COUPONS.executeQuery();
			}
			else// return all coupons with specific price
			{
				SELECT_ALL_CUSTOMER_COUPONS_BY_PRICE = super.getConnection_PreparedStatement(SQLCustomer_CouponQueries.SELECT_ALL_CUSTOMER_COUPONS_BY_PRICE_JOIN_QUERY);
				SELECT_ALL_CUSTOMER_COUPONS_BY_PRICE.setLong(1, customer.getId());
				SELECT_ALL_CUSTOMER_COUPONS_BY_PRICE.setDouble(2, price);
				
				rs = SELECT_ALL_CUSTOMER_COUPONS_BY_PRICE.executeQuery();
			}
		}
		else
		{
			if ( price == -1 )	// return all coupons of specific type
			{
				SELECT_ALL_CUSTOMER_COUPONS_BY_TYPE = super.getConnection_PreparedStatement(SQLCustomer_CouponQueries.SELECT_ALL_CUSTOMER_COUPONS_BY_TYPE_JOIN_QUERY);
				SELECT_ALL_CUSTOMER_COUPONS_BY_TYPE.setLong(1, customer.getId());
				SELECT_ALL_CUSTOMER_COUPONS_BY_TYPE.setString(2, type.toString());
				
				rs = SELECT_ALL_CUSTOMER_COUPONS_BY_TYPE.executeQuery();
			}
			else // return all coupons of specific type and specific price
			{
				
				// this condition is invalid
				
			}
		}
		
		while ( rs.next() )
		{
			Coupon coupon = new Coupon();
			coupon.setId(rs.getLong(SQLCouponColumnNames.ID));
			coupon.setTitle(rs.getString(SQLCouponColumnNames.TITLE));
			coupon.setStartDate(rs.getDate(SQLCouponColumnNames.START_DATE));
			coupon.setEndDate(rs.getDate(SQLCouponColumnNames.END_DATE));
			coupon.setAmount(rs.getInt(SQLCouponColumnNames.AMOUNT));
			coupon.setType(CouponType.valueOf(rs.getString(SQLCouponColumnNames.TYPE)));
			coupon.setMessage(rs.getString(SQLCouponColumnNames.MESSAGE));
			coupon.setPrice(rs.getDouble(SQLCouponColumnNames.PRICE));
			coupon.setImage(rs.getString(SQLCouponColumnNames.IMAGE));
			customerCoupons.add(coupon);
		}
		
		super.returnConnection();
		
		return customerCoupons;
	}

	@Override
	public boolean login(String custName, String password) throws InterruptedException, SQLException {
		PreparedStatement LOGIN = null;
		ResultSet rs = null;
		String customerName = null;
		String passWord = null;
		long id = 0;
		
		LOGIN = super.getConnection_PreparedStatement(SQLCustomerQueries.CUSTOMER_LOGIN_QUERY);
		LOGIN.setString(1, custName);	
		LOGIN.setString(2, password);
		
		rs = LOGIN.executeQuery();
		
		while( rs.next() )
		{
			customerName = rs.getString(SQLCustomerColumnNames.CUST_NAME);
			passWord = rs.getString(SQLCustomerColumnNames.PASSWORD);
		}
		
		super.returnConnection();
		
		if ( customerName !=null && passWord!= null )
		{
			customer = new Customer();
			id = storeCustomerID(customerName);
			customer.setId(id);
			System.out.println("Loggin Succesfully");
			return true;
		}
		else
		{
			System.out.println("Incorrect UserName/Password");
			return false;
		}
	}

	@Override
	public void executeUpdate(PreparedStatement preparedStatement) throws SQLException {
		preparedStatement.executeUpdate();
	}

	@Override
	public void executeQuery(PreparedStatement preparedStatement, Customer customer) throws SQLException {
		ResultSet rs = null;
		
		rs = preparedStatement.executeQuery();
		
		while( rs.next() )
		{
			customer.setId(rs.getLong(SQLCustomerColumnNames.ID));
			customer.setCustName(rs.getString(SQLCustomerColumnNames.CUST_NAME));
			customer.setPassword(rs.getString(SQLCustomerColumnNames.PASSWORD));
		}
	}

	@Override
	public void executeQueryWithArrayLisy(PreparedStatement preparedStatement, ArrayList<Customer> customerlist) throws SQLException {
		ResultSet rs = null;

		rs = preparedStatement.executeQuery();
		
		while( rs.next() )
		{
			Customer customer = new Customer();
			customer.setId(rs.getLong(SQLCustomerColumnNames.ID));
			customer.setCustName(rs.getString(SQLCustomerColumnNames.CUST_NAME));
			customer.setPassword(rs.getString(SQLCustomerColumnNames.PASSWORD));
			customerlist.add(customer);
		}
	}
	
	public boolean verifyIfCust_NameExist(Customer customer) throws InterruptedException, SQLException {
		PreparedStatement SELECT_CUST_NAME = null;
		ResultSet rs = null;
		String custName = null;
		
		SELECT_CUST_NAME = super.getConnection_PreparedStatement(SQLCustomerQueries.SELECT_CUST_NAME_QUERY);
		SELECT_CUST_NAME.setString(1, customer.getCustName());
		
		rs = SELECT_CUST_NAME.executeQuery();
		
		while( rs.next() )
		{
			custName = rs.getString(SQLCustomerColumnNames.CUST_NAME);
		}
		
		super.returnConnection();
		
		if( custName != null ) //customer name exist in DB.
		{
			return true;
		}
		else //customer name does not exist.
		{
			return false;
		}
	}
	
	public long storeCustomerID(String custName) throws InterruptedException, SQLException {
		PreparedStatement SELECT_CUST_ID = null;
		ResultSet rs = null;
		long id = 0;
		
		SELECT_CUST_ID = super.getConnection_PreparedStatement(SQLCustomerQueries.SELECT_CUST_ID_QUERY);
		SELECT_CUST_ID.setString(1, custName);
		
		rs = SELECT_CUST_ID.executeQuery();
		
		while ( rs.next() )
		{
			id = rs.getLong(SQLCustomerColumnNames.ID);
		}
		
		super.returnConnection();
		
		return id;
	}
	
	public void addCustomerCoupon(long cust_id, long coupon_id) throws InterruptedException, SQLException {
		PreparedStatement INSERT_CUSTOMER_COUPON = null;
		
		INSERT_CUSTOMER_COUPON = super.getConnection_PreparedStatement(SQLCustomer_CouponQueries.INSERT_CUSTOMER_COUPON_QUERY);
		INSERT_CUSTOMER_COUPON.setLong(1, cust_id);
		INSERT_CUSTOMER_COUPON.setLong(2, coupon_id);
		
		super.executeUpdate_ReturnConnection(INSERT_CUSTOMER_COUPON);
	}
	
	public void removeCustomerCoupon(long id, String columnName) throws InterruptedException, SQLException {
		PreparedStatement DELETE_CUSTOMER_COUPON = null;
		
		if ( columnName == SQLCustomer_CouponColumnNames.Customer_ID ) //when i want to delete the customer_id from Customer_Coupon
		{
			DELETE_CUSTOMER_COUPON = super.getConnection_PreparedStatement(SQLCustomer_CouponQueries.DELETE_CUSTOMER_COUPON_BY_CUSTOMER_ID_QUERY);
		}
		else if ( columnName == SQLCustomer_CouponColumnNames.Coupon_ID ) //when i want to delete the coupon_id from Customer_Coupon
		{
			DELETE_CUSTOMER_COUPON = super.getConnection_PreparedStatement(SQLCustomer_CouponQueries.DELETE_CUSTOMER_COUPON_BY_COUPON_ID_QUERY);
		}
		else //error, when columnName != to the options above, not likely to happen
		{
			System.out.println("error!!! please choose one of the next options for String columnName: Customer_ID or Coupon_ID");
		}
		
		DELETE_CUSTOMER_COUPON.setLong(1, id);
		
		super.executeUpdate_ReturnConnection(DELETE_CUSTOMER_COUPON);
	}
	
	public void removeMultipleCouponsFromCustomer_Coupon(long company_id) throws InterruptedException, SQLException {
		PreparedStatement DELETE_MULTIPLE_COUPONS_FROM_CUSTOMER_COUPON = null;
		
		DELETE_MULTIPLE_COUPONS_FROM_CUSTOMER_COUPON = super.getConnection_PreparedStatement(SQLCustomer_CouponQueries.DELETE_MULTIPLE_COUPONS_FROM_CUSTOMER_COUPON_QUERY);
		DELETE_MULTIPLE_COUPONS_FROM_CUSTOMER_COUPON.setLong(1, company_id);
		
		super.executeUpdate_ReturnConnection(DELETE_MULTIPLE_COUPONS_FROM_CUSTOMER_COUPON);
	}
	
	public boolean verifySingularCustomerPurchase(long coupon_ID, Customer customer) throws InterruptedException, SQLException, UniqueDataException {
		ArrayList<Customer> customerIDList = new ArrayList<>();
		
		PreparedStatement SELECT_CUSTOMER_COUPON_Customer_ID = null;
		ResultSet rs = null;
		
		SELECT_CUSTOMER_COUPON_Customer_ID = super.getConnection_PreparedStatement(SQLCustomer_CouponQueries.SELECT_CUSTOMER_COUPON_ID_QUERY);
		SELECT_CUSTOMER_COUPON_Customer_ID.setLong(1, coupon_ID);
		
		rs = SELECT_CUSTOMER_COUPON_Customer_ID.executeQuery();
		
		while ( rs.next() )
		{
			Customer mycustomer = new Customer();
			mycustomer.setId(rs.getLong(SQLCustomer_CouponColumnNames.Customer_ID));
			customerIDList.add(mycustomer);
		}
		
		super.returnConnection();
		
		if ( customerIDList.contains(customer) )
		{
			throw new UniqueDataException(UniqueDataException.purchased_Coupon); //customer already bought this coupon
		}
		else
		{
			return true; //customer didn't buy this coupon
		}
	}
	
	public void removeExpiredCustomerCoupon() throws InterruptedException, SQLException {
		PreparedStatement DELETE_EXPIRED_CUSTOMER_COUPONS = null;
		LocalDate today = LocalDate.now();
		Date currentDate = Date.valueOf(today);
		
		DELETE_EXPIRED_CUSTOMER_COUPONS = super.getConnection_PreparedStatement(SQLCustomer_CouponQueries.DELETE_EXPIRED_COUPONS_FROM_CUSTOMER_COUPON_QUERY);
		DELETE_EXPIRED_CUSTOMER_COUPONS.setDate(1, currentDate);
		
		super.executeUpdate_ReturnConnection(DELETE_EXPIRED_CUSTOMER_COUPONS);
	}
}