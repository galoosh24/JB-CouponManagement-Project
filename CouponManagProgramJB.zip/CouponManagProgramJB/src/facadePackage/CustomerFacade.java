package facadePackage;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import DAO.CouponDBDAO;
import DAO.CustomerDBDAO;
import javaBeans.Coupon;
import javaBeans.CouponType;
import javaBeans.Customer;
import myExceptions.InvalidNameOrIDException;
import myExceptions.InvalidUserNameOrPasswordException;
import myExceptions.NoExistingDataException;
import myExceptions.UniqueDataException;
import myExceptions.expiredCouponException;

public class CustomerFacade implements ClientCouponFacade {
	
	private CustomerDBDAO customerDBDAO = null;
	private CouponDBDAO couponDBDAO = null;
	private Customer customer = null;
	
	public CustomerFacade() {
		this.couponDBDAO = new CouponDBDAO();
	}
	
	public void purchaseCoupon(Coupon coupon) {
	
		try {
			if ( couponDBDAO.verifyIfCouponTitleExist(coupon) ) //
			{
				coupon.setId(couponDBDAO.getCouponID(coupon.getTitle()));
				
				if ( couponDBDAO.verifyAmountAndEnd_Date(coupon) && customerDBDAO.verifySingularCustomerPurchase(coupon.getId(), customer) ) {
					couponDBDAO.setClientType(ClientType.CUSTOMER); //for couponDBDAO.updateCoupon update coupon's amount
					
					customerDBDAO.addCustomerCoupon(customer.getId(), coupon.getId()); //joins Customer&Coupon's ID
					couponDBDAO.updateCoupon(coupon); //updates coupons amount
				}
			}
			else
			{
				throw new InvalidNameOrIDException(InvalidNameOrIDException.invalid_Coupon_Title);
			}
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		catch (expiredCouponException e3) //if amount or end_date expired
		{
			e3.getMessage();
			System.out.println(e3);
		}
		catch (InvalidNameOrIDException e4) //if coupon title dosn't exist
		{
			e4.getMessage();
			System.out.println(e4);
		}
		catch (UniqueDataException e5) //if customer already purchased this coupon
		{
			e5.getMessage();
			System.out.println(e5);
		}
	}
	
	public Collection<Coupon> getAllPurchasedCoupons() {
		ArrayList<Coupon> customerCoupons = new ArrayList<>();
		
		customerDBDAO.setCouponType(null);
		customerDBDAO.setPrice(-1);
		
		try
		{
			customerCoupons = (ArrayList<Coupon>) customerDBDAO.getCoupons();
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		
		if ( customerCoupons.isEmpty() )
		{
			try
			{
				throw new NoExistingDataException(NoExistingDataException.no_Customer_Purchase_exist);
			}
			catch (NoExistingDataException e)
			{
				e.getMessage();
				System.out.println(e);
			}
		}
		
		return customerCoupons;
	}
	
	public Collection<Coupon> getAllPurchasedCouponsByType(CouponType type) {
		ArrayList<Coupon> customerCoupons = new ArrayList<>();
		
		customerDBDAO.setCouponType(type);
		customerDBDAO.setPrice(-1);
		
		try
		{
			customerCoupons = (ArrayList<Coupon>) customerDBDAO.getCoupons();
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		
		if ( customerCoupons.isEmpty() )
		{
			try
			{
				throw new NoExistingDataException(NoExistingDataException.no_Customer_Purchase_for_type_exist + type);
			}
			catch (NoExistingDataException e)
			{
				e.getMessage();
				System.out.println(e);
			}
		}
		
		return customerCoupons;
	}
	
	public Collection<Coupon> getAllPurchasedCouponsByPrice(double price) {
		ArrayList<Coupon> customerCoupons = new ArrayList<>();
		
		customerDBDAO.setCouponType(null);
		customerDBDAO.setPrice(price);
		
		try
		{
			customerCoupons = (ArrayList<Coupon>) customerDBDAO.getCoupons();
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		
		if ( customerCoupons.isEmpty() )
		{
			try
			{
				throw new NoExistingDataException(NoExistingDataException.no_Customer_Purchase_for_price_exist + price);
			}
			catch (NoExistingDataException e)
			{
				e.getMessage();
				System.out.println(e);
			}
		}
		return customerCoupons;
	}

	@Override
	public ClientCouponFacade login(String name, String password, ClientType clientType) throws InvalidUserNameOrPasswordException {
		customerDBDAO = new CustomerDBDAO();
		long id = 0;
		ClientCouponFacade result = null;
		
		try
		{
			if( customerDBDAO.login(name, password) )
			{
				customer = new Customer();
				id = customerDBDAO.storeCustomerID(name);
				customer.setId(id);
				result = new CustomerFacade();
			}
			else
			{
				throw new InvalidUserNameOrPasswordException(InvalidUserNameOrPasswordException.invalid_UserName_Or_Password);
			}	
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		
		return result;
	}
}
