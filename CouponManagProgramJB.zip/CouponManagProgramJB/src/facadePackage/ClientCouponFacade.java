package facadePackage;

import myExceptions.InvalidUserNameOrPasswordException;

public interface ClientCouponFacade {
	
	public ClientCouponFacade login(String name, String password, ClientType clientType) throws InvalidUserNameOrPasswordException;

}
