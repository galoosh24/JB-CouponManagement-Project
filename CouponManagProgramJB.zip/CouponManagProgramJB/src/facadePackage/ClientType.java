package facadePackage;

public enum ClientType {
	
	ADMIN, COMPANY, CUSTOMER

}
