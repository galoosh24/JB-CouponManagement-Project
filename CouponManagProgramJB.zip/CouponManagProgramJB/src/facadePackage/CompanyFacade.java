package facadePackage;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import DAO.CompanyDBDAO;
import DAO.CouponDBDAO;
import DAO.CustomerDBDAO;
import SQLQueriesAndColumnNames.SQLCompany_CouponColumnNames;
import SQLQueriesAndColumnNames.SQLCustomer_CouponColumnNames;
import javaBeans.Company;
import javaBeans.Coupon;
import javaBeans.CouponType;
import myExceptions.InvalidNameOrIDException;
import myExceptions.InvalidUserNameOrPasswordException;
import myExceptions.NoExistingDataException;
import myExceptions.UsernameExistsException;

public class CompanyFacade implements ClientCouponFacade {
	
	private CouponDBDAO couponDBDAO = null; //for coupon methods
	private CompanyDBDAO companyDBDAO = null; //for login method
	private CustomerDBDAO customerDBDAO = null;
	private Company company = null; //for company ID
	
	public CompanyFacade() {
		this.couponDBDAO = new CouponDBDAO();
		this.customerDBDAO = new CustomerDBDAO();
	}
	
	public void createCoupon(Coupon coupon) {
		try
		{
			if( !couponDBDAO.verifyIfCouponTitleExist(coupon) )
			{
				couponDBDAO.creatCoupon(coupon);
				coupon.setId(couponDBDAO.getCouponID(coupon.getTitle()));
				companyDBDAO.addCompany_Coupon(company.getId(), coupon.getId());
			}
			else
			{
				throw new UsernameExistsException(UsernameExistsException.coupon_Title_Already_Exist);
			}
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		catch (UsernameExistsException e3)
		{
			e3.getMessage();
			System.out.println(e3);
		}
	}
	
	public void removeCoupon(Coupon coupon) {
		
		try
		{
			if ( couponDBDAO.verifyIfCouponTitleExist(coupon) )
			{
				coupon.setId(couponDBDAO.getCouponID(coupon.getTitle())); //getting coupon id.
				couponDBDAO.removeCoupon(coupon); //delete company
				companyDBDAO.removeCompany_Coupon(coupon.getId(), SQLCompany_CouponColumnNames.Coupon_ID); //delete coupon from company_coupon
				customerDBDAO.removeCustomerCoupon(coupon.getId(), SQLCustomer_CouponColumnNames.Coupon_ID); //delete coupon from customer_coupon
			}
			else
			{
				throw new InvalidNameOrIDException(InvalidNameOrIDException.invalid_Coupon_Title);
			}
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		catch (InvalidNameOrIDException e3)
		{
			e3.getMessage();
			System.out.println(e3);
		}
	}
	
	public void updateCoupon(Coupon coupon) {
		try
		{
			if( couponDBDAO.verifyIfCouponTitleExist(coupon) )
			{
				couponDBDAO.setClientType(ClientType.COMPANY);
				couponDBDAO.updateCoupon(coupon);
			}
			else
			{
				throw new InvalidNameOrIDException(InvalidNameOrIDException.invalid_Coupon_Title);
			}
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		catch (InvalidNameOrIDException e3)
		{
			e3.getMessage();
			System.out.println(e3);
		}
	}
	
	public Coupon getCoupon(long id) {
		Coupon coupon = new Coupon();
	
		try
		{
			coupon = couponDBDAO.getCoupon(id);
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		
		if ( coupon.getId() == 0 )
		{
			try
			{
				throw new InvalidNameOrIDException(InvalidNameOrIDException.invalid_Coupon_ID);
			}
			catch (InvalidNameOrIDException e)
			{
				e.getMessage();
				System.out.println(e);
			}
		}
		
		return coupon;
		
	}
	
	public Collection<Coupon> getAllCoupons() {
		ArrayList<Coupon> companyCoupons = new ArrayList<>();
		
		companyDBDAO.setCouponType(null); //to get all coupons type field in companyDBDAO needs to be null
		
		try
		{
			companyCoupons = (ArrayList<Coupon>) companyDBDAO.getCoupons();
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		
		if ( companyCoupons.isEmpty() )
		{
			try
			{
				throw new NoExistingDataException(NoExistingDataException.company_Coupons_doesnt_exist);
			}
			catch (NoExistingDataException e)
			{
				e.getMessage();
				System.out.println(e);
			}
		}
		
		return companyCoupons;
	}
	
	public Collection<Coupon> getCouponByType(CouponType type) {
		ArrayList<Coupon> companyCouponsByType = new ArrayList<>();
		
		companyDBDAO.setCouponType(type);
		
		try
		{
			companyCouponsByType = (ArrayList<Coupon>) companyDBDAO.getCoupons();
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		
		if ( companyCouponsByType.isEmpty() )
		{
			try
			{
				throw new NoExistingDataException(NoExistingDataException.company_Coupons_for_type_doesnt_exist + type);
			}
			catch (NoExistingDataException e)
			{
				e.getMessage();
				System.out.println(e);
			}
		}
		
		return companyCouponsByType;
	}

	@Override
	public ClientCouponFacade login(String name, String password, ClientType clientType) throws InvalidUserNameOrPasswordException {
		companyDBDAO = new CompanyDBDAO();
		long id = 0;
		ClientCouponFacade result = null;
	
		try {
			if( companyDBDAO.login(name, password) )
			{
				company = new Company();
				id = companyDBDAO.storeCompanyID(name);
				company.setId(id);
				result = new CompanyFacade();
			}
			else
			{
				throw new InvalidUserNameOrPasswordException(InvalidUserNameOrPasswordException.invalid_UserName_Or_Password);
			}
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		
		return result;
	}
}
