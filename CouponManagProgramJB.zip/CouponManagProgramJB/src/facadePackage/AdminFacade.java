package facadePackage;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import DAO.CompanyDBDAO;
import DAO.CouponDBDAO;
import DAO.CustomerDBDAO;
import SQLQueriesAndColumnNames.SQLCompany_CouponColumnNames;
import SQLQueriesAndColumnNames.SQLCustomer_CouponColumnNames;
import javaBeans.Company;
import javaBeans.Customer;
import myExceptions.InvalidNameOrIDException;
import myExceptions.InvalidUserNameOrPasswordException;
import myExceptions.UsernameExistsException;

public class AdminFacade implements ClientCouponFacade {
	
	private CompanyDBDAO companyDBDAO = null;
	private CustomerDBDAO customerDBDAO = null;
	private CouponDBDAO couponDBDAO = null;

	public AdminFacade() {
		this.companyDBDAO = new CompanyDBDAO();
		this.customerDBDAO = new CustomerDBDAO();
		this.couponDBDAO = new CouponDBDAO();
	}
	
	public void createCompany(Company company) {
		try
		{
			if ( !companyDBDAO.verifyIfComp_NameExist(company) )
			{
				companyDBDAO.createCompany(company);
			}
			else
			{
				throw new UsernameExistsException(UsernameExistsException.company_Name_Already_Exist);
			}
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		catch (UsernameExistsException e3)
		{
			e3.getMessage();
			System.out.println(e3);
		}
	}
	
	public void removeCompany(Company company) {
		try
		{
			if( companyDBDAO.verifyIfComp_NameExist(company) )
			{
				company.setId(companyDBDAO.storeCompanyID(company.getCompName())); //storing company id for future use.
				
				customerDBDAO.removeMultipleCouponsFromCustomer_Coupon(company.getId());//delete coupons from Customer_coupon using table Company_Coupon (Company_ID)
				couponDBDAO.removeMultipleCoupons(company.getId()); //delete company coupons from Coupon table
				companyDBDAO.removeCompany_Coupon(company.getId(), SQLCompany_CouponColumnNames.Company_ID); //delete company from Company_coupon
				companyDBDAO.removeCompany(company); //delete company
			}
			else
			{
				throw new InvalidNameOrIDException(InvalidNameOrIDException.invalid_Compnay_Name);
			}
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		catch (InvalidNameOrIDException e3)
		{
			e3.getMessage();
			System.out.println(e3);
		}
	}
	
	public void updateCompany(Company company) {
		
		try
		{
			if ( companyDBDAO.verifyIfComp_NameExist(company) )
			{
				companyDBDAO.updateCompany(company);
			}
			else
			{
				throw new InvalidNameOrIDException(InvalidNameOrIDException.invalid_Compnay_Name);
			}
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		catch (InvalidNameOrIDException e3)
		{
			e3.getMessage();
			System.out.println(e3);
		}
	}
	
	public Company getCompany(long id) {
		Company company = new Company();
		try
		{
			company = companyDBDAO.getCompany(id);
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		
		if ( company.getId() == 0 )
		{
			try
			{
				throw new InvalidNameOrIDException(InvalidNameOrIDException.invalid_Compnay_ID);
			}
			catch (InvalidNameOrIDException e)
			{
				e.getMessage();
				System.out.println(e);
			}
		}
		
		return company;
	}
	
	public Collection<Company> getAllCompanies() {
		ArrayList<Company> companyList = new ArrayList<>();
		
		try
		{
			companyList = (ArrayList<Company>) companyDBDAO.getAllCompanies();
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		
		return companyList;
	}
	
	public void createCustomer(Customer customer) {
		try
		{
			if( !customerDBDAO.verifyIfCust_NameExist(customer) )
			{
				customerDBDAO.createCustomer(customer);
			}
			else
			{
				throw new UsernameExistsException(UsernameExistsException.customer_Name_Already_Exist);
			}
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (UsernameExistsException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		catch (SQLException e3)
		{
			e3.getMessage();
			System.out.println(e3);
		}
	}
	
	public void removeCustomer(Customer customer) {
		try {
			if ( customerDBDAO.verifyIfCust_NameExist(customer) )
			{
				customer.setId(customerDBDAO.storeCustomerID(customer.getCustName()));
				
				customerDBDAO.removeCustomerCoupon(customer.getId(), SQLCustomer_CouponColumnNames.Customer_ID);
				customerDBDAO.removeCustomer(customer);
			}
			else
			{
				throw new InvalidNameOrIDException(InvalidNameOrIDException.invalid_Customer_Name);
			}
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		catch (InvalidNameOrIDException e3)
		{
			e3.getMessage();
			System.out.println(e3);
		}
	}
	
	public void updateCustomer(Customer customer) {
		try
		{
			if ( customerDBDAO.verifyIfCust_NameExist(customer) )
			{
				customerDBDAO.updateCustomer(customer);
			}
			else
			{
				throw new InvalidNameOrIDException(InvalidNameOrIDException.invalid_Customer_Name);
			}
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		catch (InvalidNameOrIDException e3)
		{
			e3.getMessage();
			System.out.println(e3);
		}
	}
	
	public Customer getCustomer(long id) {
		Customer customer = new Customer();
		
		try
		{
			customer = customerDBDAO.getCustomer(id);
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		
		if ( customer.getId() == 0 )
		{
			try
			{
				throw new InvalidNameOrIDException(InvalidNameOrIDException.invalid_Customer_ID);
			}
			catch (InvalidNameOrIDException e)
			{
				e.getMessage();
				System.out.println(e);
			}
		}
		
		return customer;
	}
	
	public Collection<Customer> getAllCustomers() {
		ArrayList<Customer> customerList = new ArrayList<>();
		
		try
		{
			customerList = (ArrayList<Customer>) customerDBDAO.getAllCustomers();
		}
		catch (InterruptedException e1)
		{
			e1.getMessage();
			System.out.println(e1);
		}
		catch (SQLException e2)
		{
			e2.getMessage();
			System.out.println(e2);
		}
		
		return customerList;
	}
	
	@Override
	public ClientCouponFacade login(String admin, String password, ClientType clientType) throws InvalidUserNameOrPasswordException {
		ClientCouponFacade result = null;
		
		if( admin == "admin" && password == "1234" )
		{
			result = new AdminFacade();
			System.out.println("Loggin Succesfully");
		}
		else
		{
			throw new InvalidUserNameOrPasswordException(InvalidUserNameOrPasswordException.invalid_UserName_Or_Password);
		}
		
		return result;
	}
}
