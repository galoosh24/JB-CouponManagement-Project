package SQLQueriesAndColumnNames;

public class SQLCustomer_CouponQueries {
	
	public static final String INSERT_CUSTOMER_COUPON_QUERY = "INSERT INTO Customer_Coupon (Customer_ID, Coupon_ID) VALUES (?, ?)";
	
	
	public static final String DELETE_CUSTOMER_COUPON_BY_COUPON_ID_QUERY = "DELETE FROM Customer_Coupon WHERE Coupon_ID=?";
	
	public static final String DELETE_CUSTOMER_COUPON_BY_CUSTOMER_ID_QUERY = "DELETE FROM Customer_Coupon WHERE Customer_ID=?";
	
	public static final String DELETE_MULTIPLE_COUPONS_FROM_CUSTOMER_COUPON_QUERY = "DELETE FROM Customer_Coupon WHERE Coupon_ID IN (SELECT Coupon_ID FROM Company_Coupon WHERE Compnay_ID=?)";
	
	public static final String DELETE_EXPIRED_COUPONS_FROM_CUSTOMER_COUPON_QUERY = "DELETE FROM Customer_Coupon WHERE Coupon_ID IN (SELECT Coupon_ID FROM Coupon WHERE END_DATE<?)";
	
	
	public static final String SELECT_ALL_CUSTOMER_COUPONS_JOIN_QUERY = "SELECT c.ID, c.TITLE, c.START_DATE, c.END_DATE, c.AMOUNT, c.TYPE, c.MESSAGE, c.PRICE, c.IMAGE FROM Coupon c JOIN Customer_Coupon c_c ON c.ID = c_c.Coupon_ID WHERE c_c.Customer_ID=?";

	public static final String SELECT_ALL_CUSTOMER_COUPONS_BY_TYPE_JOIN_QUERY = "SELECT c.ID, c.TITLE, c.START_DATE, c.END_DATE, c.AMOUNT, c.TYPE, c.MESSAGE, c.PRICE, c.IMAGE FROM Coupon c JOIN Customer_Coupon c_c ON c.ID = c_c.Coupon_ID WHERE c_c.Customer_ID=? AND c.TYPE=?";
	
	public static final String SELECT_ALL_CUSTOMER_COUPONS_BY_PRICE_JOIN_QUERY = "SELECT c.ID, c.TITLE, c.START_DATE, c.END_DATE, c.AMOUNT, c.TYPE, c.MESSAGE, c.PRICE, c.IMAGE FROM Coupon c JOIN Customer_Coupon c_c ON c.ID = c_c.Coupon_ID WHERE c_c.Customer_ID=? AND c.PRICE<=?";
	
	public static final String SELECT_CUSTOMER_COUPON_ID_QUERY = "SELECT Customer_ID FROM Customer_Coupon Where Coupon_ID=?";
}
