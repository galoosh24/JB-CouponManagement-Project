package SQLQueriesAndColumnNames;

public class SQLCompanyColumnNames {
	
	public static final String ID = "ID";
	public static final String COMP_NAME = "COMP_NAME";
	public static final String PASSWORD = "PASSWORD";
	public static final String EMAIL = "EMAIL";

}
