package SQLQueriesAndColumnNames;

public class SQLCustomerColumnNames {
	
	public static final String ID = "ID";
	public static final String CUST_NAME = "CUST_NAME";
	public static final String PASSWORD = "PASSWORD";

}
