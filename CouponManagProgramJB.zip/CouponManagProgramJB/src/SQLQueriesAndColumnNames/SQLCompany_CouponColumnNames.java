package SQLQueriesAndColumnNames;

public class SQLCompany_CouponColumnNames {
	
	public static final String Company_ID = "Company_ID";
	
	public static final String Coupon_ID = "Coupon_ID";

}
