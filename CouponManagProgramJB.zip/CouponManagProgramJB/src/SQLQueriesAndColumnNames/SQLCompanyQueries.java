package SQLQueriesAndColumnNames;


public class SQLCompanyQueries {
	
	public static final String INSERT_COMPANY_QUERY = "INSERT INTO Company (COMP_NAME, PASSWORD, EMAIL) VALUES (?, ?, ?)";
	
	
	public static final String DELETE_COMPANY_QUERY = "DELETE FROM Company WHERE COMP_NAME=?";
	
	
	public static final String UPDATE_COMPANY_QUERY = "UPDATE Company SET PASSWORD=?, EMAIL=? WHERE COMP_NAME=?";
	
	
	public static final String SELECT_COMPANY_QUERY = "SELECT ID, COMP_NAME, PASSWORD, EMAIL FROM Company WHERE ID=?";
	
	public static final String SELECT_ALL_COMPANEIS_QUERY = "SELECT * FROM CouponManagDB.Company";
	
	public static final String SELECT_COMPANY_LOGIN_QUERY = "SELECT COMP_NAME, PASSWORD FROM CouponManagDB.Company WHERE COMP_NAME=? AND PASSWORD=?";
	
	public static final String SELECT_COMP_NAME_QUERY = "SELECT COMP_NAME FROM Company WHERE COMP_NAME=?";
	
	public static final String SELECT_COMP_ID_QUERY = "SELECT ID FROM Company WHERE COMP_NAME=?";

}
