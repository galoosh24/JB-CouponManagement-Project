package SQLQueriesAndColumnNames;

public class SQLCompany_CouponQueries {

	public static final String INSERT_COMPANY_COUPON_QUERY = "INSERT INTO Company_Coupon (Company_ID, Coupon_ID) VALUES (?, ?)";
	
	
	public static final String DELETE_COMPANY_COUPON_BY_COUPON_ID_QUERY = "DELETE FROM Company_Coupon WHERE Coupon_ID=?";
	
	public static final String DELETE_COMPANY_COUPON_BY_COMPANY_ID_QUERY = "DELETE FROM Company_Coupon WHERE Company_ID=?";
	
	public static final String DELETE_EXPIRED_COUPONS_FROM_COMPANY_COUPON_QUERY = "DELETE FROM Company_Coupon WHERE Coupon_ID IN (SELECT Coupon_ID FROM Coupon WHERE END_DATE<?)";
	
	
	public static final String SELECT_ALL_COMPANY_COUPONS_JOIN_QUERY = "SELECT c.ID, c.TITLE, c.START_DATE, c.END_DATE, c.AMOUNT, c.TYPE, c.MESSAGE, c.PRICE, c.IMAGE FROM Coupon c JOIN Company_Coupon c_c ON c.ID = c_c.Coupon_ID WHERE c_c.Company_ID=?";
	
	public static final String SELECT_ALL_COMPANY_COUPONS_BY_TYPE_JOIN_QUERY = "SELECT c.ID, c.TITLE, c.START_DATE, c.END_DATE, c.AMOUNT, c.TYPE, c.MESSAGE, c.PRICE, c.IMAGE FROM Coupon c JOIN Company_Coupon c_c ON c.ID = c_c.Coupon_ID WHERE c_c.Company_ID=? AND c.TYPE=?";
}
