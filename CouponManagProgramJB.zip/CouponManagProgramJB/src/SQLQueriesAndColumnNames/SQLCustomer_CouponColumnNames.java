package SQLQueriesAndColumnNames;

public class SQLCustomer_CouponColumnNames {
	
	public static final String Customer_ID = "Customer_ID";
	
	public static final String Coupon_ID = "Coupon_ID";

}
