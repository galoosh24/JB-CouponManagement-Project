package SQLQueriesAndColumnNames;

public class SQLCouponColumnNames {
	
	public static final String ID = "ID";
	
	public static final String TITLE = "TITLE";
	
	public static final String START_DATE = "START_DATE";
	
	public static final String END_DATE = "END_DATE";
	
	public static final String AMOUNT = "AMOUNT";
	
	public static final String TYPE = "TYPE";
	
	public static final String MESSAGE = "MESSAGE";
	
	public static final String PRICE = "PRICE";
	
	public static final String IMAGE = "IMAGE";
}
