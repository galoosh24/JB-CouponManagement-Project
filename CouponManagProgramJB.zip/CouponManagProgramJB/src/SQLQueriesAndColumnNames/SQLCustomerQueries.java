package SQLQueriesAndColumnNames;

public class SQLCustomerQueries {
	
	public static final String INSERT_CUSTOMER_QUERY = "INSERT INTO Customer (CUST_NAME, PASSWORD) VALUES (?, ?)";
	
	public static final String DELETE_CUSTOMER_QUERY = "DELETE FROM Customer WHERE CUST_NAME=?";
	
	public static final String UPDATE_CUSTOMER_QUERY = "UPDATE Customer SET PASSWORD=? WHERE CUST_NAME=?";
	
	public static final String SELECT_CUSTOMER_QUERY = "SELECT ID, CUST_NAME, PASSWORD FROM Customer WHERE ID=?";
	
	public static final String SELECT_ALL_CUSTOMERS_QUERY = "SELECT * FROM CouponManagDB.Customer";
	
	public static final String CUSTOMER_LOGIN_QUERY = "SELECT CUST_NAME, PASSWORD FROM CouponManagDB.Customer WHERE CUST_NAME=? AND PASSWORD=?";
	
	public static final String SELECT_CUST_NAME_QUERY = "SELECT CUST_NAME FROM Customer WHERE CUST_NAME=?";
	
	public static final String SELECT_CUST_ID_QUERY = "SELECT ID FROM Customer WHERE CUST_NAME=?";

}
