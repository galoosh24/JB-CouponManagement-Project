package SQLQueriesAndColumnNames;

public class SQLCouponQueries {
	
	public static final String INSERT_COUPON_QUERY = "INSERT INTO Coupon (TITLE, START_DATE, END_DATE, AMOUNT, TYPE, MESSAGE, PRICE, IMAGE) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
	
	
	public static final String DELETE_COUPON_QUERY = "DELETE FROM Coupon WHERE TITLE=?";
	
	public static final String DELETE_MULTIPLE_COUPONS_JOIN_QUERY = "DELETE c FROM Coupon c JOIN Company_Coupon c_c ON c.ID = c_c.Coupon_ID WHERE c_c.Company_ID=?";
	
	public static final String DELETE_EXPIRED_COUPONS_QUERY = "DELETE FROM Coupon WHERE END_DATE<?";
	
	
	public static final String UPDATE_COUPON_QUERY = "UPDATE Coupon SET END_DATE=?, PRICE=? WHERE TITLE=?";
	
	public static final String UPDATE_COUPON_AMOUNT_QUERY = "UPDATE Coupon SET AMOUNT= AMOUNT-1 WHERE TITLE=?";
	
	
	public static final String SELECT_COUPON_QUERY = "SELECT ID, TITLE, START_DATE, END_DATE, AMOUNT, TYPE, MESSAGE, PRICE, IMAGE FROM Coupon WHERE ID=?";
	
	public static final String SELECT_ALL_COUPON_QUERY = "SELECT * FROM CouponManagDB.Coupon";
	
	public static final String SELECT_ALL_COUPON_BY_TYPE_QUERY = "SELECT * FROM CouponManagDB.Coupon WHERE TYPE=?";
	
	public static final String SELECT_COUPON_TITLE_QUERY = "SELECT TITLE FROM Coupon WHERE TITLE=?";
	
	public static final String SELECT_COUPON_ID_QUERY = "SELECT ID FROM Coupon WHERE TITLE=?";
	
	public static final String SELECT_COUPON_AMOUNT_AND_END_DATE = "SELECT AMOUNT, END_DATE FROM Coupon WHERE TITLE=?";
}
