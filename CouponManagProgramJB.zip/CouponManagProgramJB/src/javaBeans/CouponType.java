package javaBeans;

public enum CouponType {
	
	RESTURANTS, ELECTRICITY, FOOD, HEALTH, SPORTS, CAMPING, TRAVELLING

}
